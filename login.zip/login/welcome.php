<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    body{
padding: 0;
margin: 0;
font-family: Arial, Helvetica, sans-serif;
}
section.cover{
background: linear-gradient(45deg,#151680 50%,#261681 50%);
padding: 20px 10%;
border-bottom: 50px solid transparent;
border-bottom-left-radius: 20px;
border-bottom-right-radius: 20px;
}
section nav{
display: flex;
justify-content: space-between;
align-items: center;
font-size: 1.4rem;
color: #fff;
}
section nav ul{
list-style-type: none;
font-size: 0.8rem;
}
section nav ul li {
float: left;
padding: 10px;
}

div.cta-btn{
margin: 40px 0 20px 0;
}
div.cta-btn a{
padding: 10px 20px;
background-color: #D20B54;
text-decoration: none;
color: #fff;
border-radius: 5px;
}
section.cover .content .heading{
font-size: 2.5rem;
font-weight: 500;
}
section.cover .content{
color: #fff;
padding: 40px 0;
position: relative;
}
section.cover .content .highlight{
font-size: 10px;
}
section.cover .content .card{
position: absolute;
bottom: 10px;
right: 0;
width: 140px;
padding: 20px 40px;
background-color: #fff;
color: #888;
border-radius: 5px;
transition: 200ms all ease-in-out;
cursor: pointer;
}
section.cover .content .card:hover{
transform: translateY(-5px);
color: #222;
}



.main {
width: 100%;
height: 100%;
background-color: #f2f2f2;
overflow-y: scroll;
overflow-x: hidden;
}
h1 {
margin: 0;
font-size: 40px;
margin-top: 35pt;
margin-left: 20pt;
font-weight: bold;
}
h2 {
margin: 0;
margin-left: 20pt;
margin-top: 30pt;
margin-bottom: 15pt;
}
h3 {
font-family: monospace;
font-weight: light;
margin: 0;
margin-left: 20pt;
margin-top: 15pt;
font-size: 16px;
}
h3 a:link, h3 a:visited, h3 a:active, h3 a:hover{
color: #333;
}
.row {
background-color: none;
width: calc(100% - 20pt);
height: 200pt;
margin-left: 20pt;
margin-bottom: 20pt;
overflow-x: scroll;
overflow-y: hidden;
white-space:nowrap
}
.item {
display: inline-block;
width: 250pt;
height: 200pt;
background-color: #fff;
border-radius: 6pt;
margin-right: 15pt;
transition: 0.2s ease-in-out;
}
.item:link, .item:visited, .item:active {
color: #333;
text-decoration: none;
}
.item:hover {
opacity: 0.75;
transform: scale(0.98);
color: #333;
text-decoration: none;
}
.image {
height: 150pt;
width: 250pt;
backgroud-color: #ddd;
border-radius: 6pt 6pt 0pt 0pt;
background-size: cover;
background-position: center center;
}
.item_description {
margin: 0;
padding-top: 18pt;
font-size: 17px;
margin-left: 10pt;
margin-right: 10pt;
text-align: center;
font-family: monospace;
}
.button {
  background-color: #cc0066;
  border: none;
  color: white;
  padding: 10px 32px;
  text-align: center;
  font-size: 16px;
  margin: -10px 2px;
  transition: 0.3s;
  display: inline-block;
  text-decoration: none;
  cursor: pointer;
  border-radius: 10px;
}

.button:hover {opacity: 1}

a:link {
  color: white;
  text-decoration: none;
}
    </style>
  </head>
  <body>
    <section class="cover">
  <nav>
    <span class="logo">
    Cyber crime reporting portal
  </span>
    <ul>
      <li>Home</li>
      <li>About Us</li>
      <li>Contact Us</li>
      <li>
        <button class="button"><a  href="http://localhost/login/logout.php">Logout</a></button>
      </li>
      <div class="page-header">
          <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to our site.</h1>
      </div>
    </ul>
  </nav>
  <div class="content">
    <h2 class="heading">We are here for all your need.</h2>
    <div class="cta-btn">
    <a href="#">Get Started</a>
    </div>
  </div>
</section>

<div class="main">
  <h1>Services</h1>
  <h2>Safety</h2>
  <div class="row">
    <a class="item" href="http://localhost/Online_FIR_System/registercomplaint.php">
      <div class="image" style="background-image: url(https://www.cambridgeenglish.org/static-assets/Images/a1w004-filling-in-a-form_tcm32-289257.jpg);"></div>
      <p class="item_description">Register Complaint</p>
    </a>
    <a class="item" href="http://localhost/Online_FIR_System/Login/firlogin.html">
      <div class="image" style="background-image: url(https://ak2.picdn.net/shutterstock/videos/1276372/thumb/2.jpg);"></div>
      <p class="item_description">FIR Status</p>
    </a>
    <a class="item" href="http://localhost/Online_FIR_System/Login/login.html">
      <div class="image" style="background-image: url(https://otb.cachefly.net/wp-content/uploads/2015/11/Police-Badge.jpg);"></div>
      <p class="item_description">Authority login</p>
    </a>
  </div>

</div>

  </body>
</html>
