-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 14, 2019 at 07:06 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdms`
--
CREATE DATABASE IF NOT EXISTS `bbdms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bbdms`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '2019-10-14 17:29:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblblooddonars`
--

DROP TABLE IF EXISTS `tblblooddonars`;
CREATE TABLE IF NOT EXISTS `tblblooddonars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(100) DEFAULT NULL,
  `MobileNumber` char(11) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Message` mediumtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblblooddonars`
--

INSERT INTO `tblblooddonars` (`id`, `FullName`, `MobileNumber`, `EmailId`, `Gender`, `Age`, `BloodGroup`, `Address`, `Message`, `PostingDate`, `status`) VALUES
(6, 'Sumanth Reddy', '9787773988', 'webtechie985@gmail.com', 'Male', 19, 'A+', 'Vit University\r\nVit University', ' o+', '2019-10-14 17:31:00', 1),
(7, 'Ruthvik', '8328511623', 'webtechie985@gmail.com', 'Male', 19, 'AB-', 'Vit University\r\nVit University', ' Donate', '2019-10-14 17:31:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblbloodgroup`
--

DROP TABLE IF EXISTS `tblbloodgroup`;
CREATE TABLE IF NOT EXISTS `tblbloodgroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbloodgroup`
--

INSERT INTO `tblbloodgroup` (`id`, `BloodGroup`, `PostingDate`) VALUES
(1, 'A-', '2017-06-30 20:33:50'),
(2, 'AB-', '2017-06-30 20:34:00'),
(3, 'O-', '2017-06-30 20:34:05'),
(4, 'A-', '2017-06-30 20:34:10'),
(5, 'A+', '2017-06-30 20:34:13'),
(6, 'AB+', '2017-06-30 20:34:18'),
(7, 'O+', '2019-10-14 17:34:17');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusinfo`
--

DROP TABLE IF EXISTS `tblcontactusinfo`;
CREATE TABLE IF NOT EXISTS `tblcontactusinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Address` tinytext,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactusinfo`
--

INSERT INTO `tblcontactusinfo` (`id`, `Address`, `EmailId`, `ContactNo`) VALUES
(1, 'CMC,Vellore																									', 'webtechie985@gmail.com', '8585233222');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

DROP TABLE IF EXISTS `tblcontactusquery`;
CREATE TABLE IF NOT EXISTS `tblcontactusquery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

DROP TABLE IF EXISTS `tblpages`;
CREATE TABLE IF NOT EXISTS `tblpages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(2, 'Why Become Donor', 'donor', '<p style=\"margin-top: 0.5em; margin-bottom: 0.5em; color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;\">A&nbsp;<b>blood donation</b>&nbsp;occurs when a person voluntarily has&nbsp;<a href=\"https://en.wikipedia.org/wiki/Blood\" title=\"Blood\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">blood</a>&nbsp;drawn and used for&nbsp;<a href=\"https://en.wikipedia.org/wiki/Blood_transfusion\" title=\"Blood transfusion\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">transfusions</a>&nbsp;and/or made into biopharmaceutical medications by a process called&nbsp;<a href=\"https://en.wikipedia.org/wiki/Blood_fractionation\" title=\"Blood fractionation\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">fractionation</a>&nbsp;(separation of whole-blood components). Donation may be of whole blood, or of specific components directly (the latter called apheresis).&nbsp;<a href=\"https://en.wikipedia.org/wiki/Blood_bank\" title=\"Blood bank\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">Blood banks</a>&nbsp;often participate in the collection process as well as the procedures that follow it.</p><p style=\"margin-top: 0.5em; margin-bottom: 0.5em; color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;\">Today in the developed world, most blood donors are unpaid volunteers who donate blood for a community supply. In some countries, established supplies are limited and donors usually give blood when family or friends need a transfusion (directed donation). Many donors donate as an act of charity, but in countries that allow paid donation some donors are paid, and in some cases there are incentives other than money such as&nbsp;<a href=\"https://en.wikipedia.org/wiki/Paid_time_off\" title=\"Paid time off\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">paid time off</a>&nbsp;from work. Donors can also have blood drawn for their own future use (<a href=\"https://en.wikipedia.org/wiki/Autologous_blood_donation\" class=\"mw-redirect\" title=\"Autologous blood donation\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">autologous donation</a>). Donating is relatively safe, but some donors have bruising where the needle is inserted or may feel faint.</p><p style=\"margin-top: 0.5em; margin-bottom: 0.5em; color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;\">Potential donors are evaluated for anything that might make their blood unsafe to use. The screening includes testing for diseases that can be transmitted by a blood transfusion, including&nbsp;<a href=\"https://en.wikipedia.org/wiki/HIV\" title=\"HIV\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">HIV</a>&nbsp;and&nbsp;<a href=\"https://en.wikipedia.org/wiki/Viral_hepatitis\" title=\"Viral hepatitis\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">viral hepatitis</a>. The donor must also answer questions about&nbsp;<a href=\"https://en.wikipedia.org/wiki/Medical_history\" title=\"Medical history\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">medical history</a>&nbsp;and take a short&nbsp;<a href=\"https://en.wikipedia.org/wiki/Physical_examination\" title=\"Physical examination\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">physical examination</a>&nbsp;to make sure the donation is not hazardous to his or her health. How often a donor can donate varies from days to months based on what component they donate and the laws of the country where the donation takes place. For example, in the United States, donors must wait eight weeks (56 days) between&nbsp;<a href=\"https://en.wikipedia.org/wiki/Blood_donation#Whole_blood\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">whole blood donations</a>&nbsp;but only seven days between&nbsp;<a href=\"https://en.wikipedia.org/wiki/Plateletpheresis\" title=\"Plateletpheresis\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">plateletpheresis donations</a>&nbsp;and twice per seven-day period in&nbsp;<a href=\"https://en.wikipedia.org/wiki/Plasmapheresis\" title=\"Plasmapheresis\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">plasmapheresis</a>.<sup id=\"cite_ref-1\" class=\"reference\" style=\"line-height: 1; unicode-bidi: isolate; white-space: nowrap; font-size: 11.2px;\"><a href=\"https://en.wikipedia.org/wiki/Blood_donation#cite_note-1\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">[1]</a></sup></p><p style=\"margin-top: 0.5em; margin-bottom: 0.5em; color: rgb(34, 34, 34); font-family: sans-serif; font-size: 14px;\">The amount of blood drawn and the methods vary. The collection can be done manually or with automated equipment that takes only specific components of the blood. Most of the components of blood used for transfusions have a short&nbsp;<a href=\"https://en.wikipedia.org/wiki/Shelf_life\" title=\"Shelf life\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">shelf life</a>, and maintaining a constant supply is a persistent problem. This has led to some increased interest in&nbsp;<a href=\"https://en.wikipedia.org/wiki/Autotransfusion\" title=\"Autotransfusion\" style=\"color: rgb(11, 0, 128); background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">autotransfusion</a>, whereby a patient\'s blood is salvaged during surgery for continuous reinfusion—or alternatively, is \"self-donated\"&nbsp;<i>prior</i>&nbsp;to when it will be needed. (Generally, the notion of \"donation\" does not refer to giving to one\'s&nbsp;<i>self</i>, though in this context it has become somewhat acceptably idiomatic.)</p>'),
(3, 'About Us ', 'aboutus', '																				<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; text-align: justify;\">Blood Bank. E-portal</span>\r\n										');
--
-- Database: `complaints`
--
CREATE DATABASE IF NOT EXISTS `complaints` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `complaints`;

-- --------------------------------------------------------

--
-- Table structure for table `cops`
--

DROP TABLE IF EXISTS `cops`;
CREATE TABLE IF NOT EXISTS `cops` (
  `id` bigint(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(300) NOT NULL,
  `Post` varchar(300) NOT NULL,
  `Category` varchar(300) NOT NULL,
  `Email` varchar(300) NOT NULL,
  `Password` varchar(300) NOT NULL,
  `Count` bigint(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cops`
--

INSERT INTO `cops` (`id`, `Name`, `Post`, `Category`, `Email`, `Password`, `Count`) VALUES
(1, 'Pradhyuman', 'SI', 'Murder', 'pradh@gmail.com', 'daya', 0),
(3, 'Abhijeet', 'ASI', '', 'abhijeet@gmail.com', 'abhi', 0),
(4, 'Sumanth ', 'SI', 'Theft & Robbery', 'sumanthreddy329@gmail.com', '123456', 0),
(6, 'Anubhav Tyagi', 'SI', 'Domestic Affairs', 'tyagi@gmail.com', 'tyagi', 0),
(7, 'Manan Gupta', 'SI', 'Others', 'gupta@gmail.com', 'man', 0),
(8, 'Ruthvik', 'SI', 'Theft & Robbery', 'ruthvik@gmail.com', '123456', 0),
(9, 'Ravi Shankar', 'SI', 'Domestic Affairs', 'shank@gmail.com', 'ravi', 1),
(10, 'Anant Sachan', 'SI', 'Murder', 'sachan@gmail.com', 'anant', 0),
(11, 'Shubham Maurya', 'SI', 'Others', 'maurya@gmail.com', 'maurya', 0),
(12, 'Abhishek Jaiswal', 'ASI', '', 'jaiswal@gmail.com', 'abhi', 0),
(13, 'Aman Raj', 'ASI', '', 'raj@gmail.com', 'aman', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fir`
--

DROP TABLE IF EXISTS `fir`;
CREATE TABLE IF NOT EXISTS `fir` (
  `SNo` bigint(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) DEFAULT NULL,
  `Age` int(150) DEFAULT NULL,
  `Address` varchar(300) DEFAULT NULL,
  `Inc_DateTime` datetime(6) DEFAULT NULL,
  `Reg_DateTime` datetime(6) DEFAULT NULL,
  `Complaint` varchar(500) DEFAULT NULL,
  `Section` varchar(255) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL,
  `Approved` tinyint(1) NOT NULL DEFAULT '0',
  `SIID` bigint(255) DEFAULT NULL,
  `Status` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`SNo`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fir`
--

INSERT INTO `fir` (`SNo`, `Name`, `Age`, `Address`, `Inc_DateTime`, `Reg_DateTime`, `Complaint`, `Section`, `Category`, `Approved`, `SIID`, `Status`) VALUES
(6, 'Abhishek Jaiswal', 20, 'B-316', '2019-05-16 23:56:00.000000', '2019-05-01 21:03:55.000000', 'Attempt to Murder', '344', 'Murder', 1, 1, 'Accused Arrested!'),
(8, 'Ankur Ingale', 23, 'C-112', '2019-05-10 23:55:00.000000', '2019-05-01 22:38:18.000000', 'Others', '999', 'Others', 1, 7, 'Case Closed!'),
(9, 'Mihir Yadav', 35, 'C-116', '2019-05-14 18:56:00.000000', '2019-05-01 22:42:16.000000', 'Domestic Violence', '304', 'Domestic Affairs', 1, 6, 'Case solved!'),
(10, 'Anant Sachan', 56, 'C-112', '2019-05-23 12:23:00.000000', '2019-05-01 22:45:08.000000', 'Theft', '304', 'Theft & Robbery', 0, 8, NULL),
(11, 'Parvinder', 56, 'C-112', '2019-05-23 12:23:00.000000', '2019-05-01 22:50:31.000000', 'Attempt to Murder', '344', 'Murder', 0, 4, NULL),
(12, 'Kanishq Agarwal', 45, 'C-111', '2019-05-05 12:23:00.000000', '2019-05-01 22:51:03.000000', 'Others', '999', 'Others', 0, 8, NULL),
(13, 'Anirudh Agarwal', 45, 'C-178', '2019-05-05 12:23:00.000000', '2019-05-01 22:53:38.000000', 'Domestic Violence', '304', 'Domestic Affairs', 1, 9, NULL),
(14, 'Ashutosh ', 23, 'C-278', '2019-05-06 12:23:00.000000', '2019-05-01 22:59:21.000000', 'Attempt to Murder', '344', 'Murder', 0, NULL, NULL),
(15, 'Kushal', 26, 'C-289', '2019-05-04 12:56:00.000000', '2019-05-01 23:00:03.000000', 'Others', '999', 'Others', 0, NULL, NULL),
(16, 'Ashish', 22, 'C-028', '2019-05-28 12:56:00.000000', '2019-05-01 23:03:59.000000', 'Theft', '304', 'Theft & Robbery', 0, NULL, NULL),
(17, 'Abhishek', 11, 'C114', '2020-02-01 00:01:00.000000', '2019-05-01 23:17:02.000000', 'Attempt to Murder', '344', 'Murder', 1, 1, 'done bro'),
(18, 'Sumanth', 19, 'Vit University\r\nVit University', '2019-10-31 23:00:00.000000', '2019-10-14 19:47:12.000000', 'Theft', '304', 'Theft & Robbery', 0, 4, NULL),
(19, 'Sumanth', 19, 'Vit University\r\nVit University', '2019-10-31 23:00:00.000000', '2019-10-14 19:47:18.000000', 'Theft', '304', 'Theft & Robbery', 0, 8, NULL),
(20, 'Ruthvik', 19, 'Vit University\r\nVit University', '2019-10-25 20:00:00.000000', '2019-10-14 23:28:40.000000', 'Theft', '304', 'Theft & Robbery', 0, 8, NULL);
--
-- Database: `db_evoting`
--
CREATE DATABASE IF NOT EXISTS `db_evoting` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_evoting`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `admin_username` varchar(30) NOT NULL,
  `admin_password` varchar(30) NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`aid`, `admin_username`, `admin_password`, `time_stamp`) VALUES
(1, 'admin', '123456', '2019-10-14 18:08:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `voter_id` int(10) NOT NULL,
  `voted_for` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `full_name`, `email`, `voter_id`, `voted_for`) VALUES
(1, 'Abhishek Kumar Ravi', 'don.coolbuddy.xxx@gmail.com', 546754, 'BJP'),
(3, 'Chadan', 'chabdan@gmail.com', 65786, 'BJP'),
(4, 'Aman', 'aman@live.in', 896740, 'BJP'),
(5, 'Vicky', 'lastworker@gmail.com', 45432, 'BJP'),
(6, 'Abhishek Singh', 'abhi6751@gmail.com', 87430, 'BJP'),
(7, 'Avneet', 'avneet@gmail.com', 74629, 'INC'),
(8, 'Santanu', 'santa@gmail.com', 89378, 'TMC'),
(9, 'Arvind Kejriwal', 'arvind@gmail.com', 94940, 'AAP'),
(10, 'Manish Sisodia', 'manish@live.in', 6483, 'AAP'),
(11, 'Rahul Raju', 'rahulraj@hmail.com', 9749403, 'INC'),
(12, 'Subham Kumar', 'subham@gmail.com', 95678, 'AAP'),
(13, 'Chadan', 'chabdan@gmail.com', 5, 'BJP'),
(14, 'Abhishek Singh', 'abhi6751@gmail.com', 12345, 'TMC'),
(15, 'Abhishek Kumar', 'ak@gmail.com', 12345, 'TMC'),
(16, 'Sumanth', 'sumanth@gmail.com', 32325132, 'INC'),
(17, 'Sumanth', '323457119368', 32325132, 'INC');
--
-- Database: `db_sams`
--
CREATE DATABASE IF NOT EXISTS `db_sams` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_sams`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

DROP TABLE IF EXISTS `tbl_attendance`;
CREATE TABLE IF NOT EXISTS `tbl_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roll` int(11) NOT NULL,
  `attend` varchar(255) NOT NULL,
  `att_time` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`id`, `roll`, `attend`, `att_time`) VALUES
(1, 1, 'absent', '2019-01-16'),
(2, 2, 'present', '2019-01-16'),
(3, 3, 'absent', '2019-01-16'),
(4, 4, 'absent', '2019-01-16'),
(5, 5, 'present', '2019-01-16'),
(6, 6, 'present', '2019-01-16'),
(7, 7, 'absent', '2019-01-16'),
(9, 1, 'present', '2019-01-17'),
(10, 2, 'present', '2019-01-17'),
(11, 3, 'absent', '2019-01-17'),
(12, 4, 'absent', '2019-01-17'),
(13, 5, 'present', '2019-01-17'),
(14, 6, 'absent', '2019-01-17'),
(15, 7, 'present', '2019-01-17'),
(31, 6, 'absent', '2019-01-18'),
(30, 5, 'absent', '2019-01-18'),
(29, 4, 'present', '2019-01-18'),
(28, 3, 'present', '2019-01-18'),
(27, 2, 'present', '2019-01-18'),
(26, 1, 'present', '2019-01-18'),
(32, 7, 'present', '2019-01-18'),
(33, 1, 'present', '2019-10-15'),
(34, 2, 'absent', '2019-10-15'),
(35, 3, 'present', '2019-10-15'),
(36, 4, 'absent', '2019-10-15'),
(37, 5, 'present', '2019-10-15'),
(38, 6, 'absent', '2019-10-15'),
(39, 7, 'present', '2019-10-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

DROP TABLE IF EXISTS `tbl_student`;
CREATE TABLE IF NOT EXISTS `tbl_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `roll` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`id`, `name`, `roll`) VALUES
(1, 'Md. Shakil Ahmed', 1),
(2, 'Abdullah Al Mamun', 2),
(3, 'Anayet Ullah', 3),
(4, 'Mahmudul Hassan', 4),
(5, 'Mehedi Hasan', 5),
(6, 'Jahirul Islam', 6),
(7, 'Arman Khan', 7);
--
-- Database: `demo`
--
CREATE DATABASE IF NOT EXISTS `demo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `demo`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` decimal(12,0) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, '323457119368', '$2y$10$kA58xquHcRD82ECgg1KEDurp6KdFU5ALI9vJ3SrFk6ZtxvcPPYYf2', '2019-10-14 22:24:52');
--
-- Database: `hms`
--
CREATE DATABASE IF NOT EXISTS `hms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hms`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', 'Test@12345', '28-12-2016 11:42:05 AM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE IF NOT EXISTS `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctorSpecialization` varchar(255) NOT NULL,
  `doctorId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `consultancyFees` int(11) NOT NULL,
  `appointmentDate` varchar(255) NOT NULL,
  `appointmentTime` varchar(255) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userStatus` int(11) NOT NULL,
  `doctorStatus` int(11) NOT NULL,
  `updationDate` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(1, 'Dentist', 1, 1, 500, '2016-12-31', '09:25', '2017-01-01 00:29:02', 1, 0, ''),
(2, 'Homeopath', 4, 5, 700, '2017-01-11', '14:10', '2017-01-07 08:02:58', 0, 1, ''),
(3, 'Ayurveda', 8, 6, 600, '2019-06-29', '9:15 AM', '2019-06-23 18:31:28', 1, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE IF NOT EXISTS `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'Dentist', 'Anuj', 'New Delhi', '500', 8285703354, 'anuj.lpu1@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2016-12-29 06:25:37', '2019-06-30 12:11:05'),
(2, 'Homeopath', 'Sarita Pandey', 'Varanasi', '600', 2147483647, 'sarita@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2016-12-29 06:51:51', '0000-00-00 00:00:00'),
(3, 'General Physician', 'Nitesh Kumar', 'Ghaziabad', '1200', 8523699999, 'nitesh@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 07:43:35', '0000-00-00 00:00:00'),
(4, 'Homeopath', 'Vijay Verma', 'New Delhi', '700', 25668888, 'vijay@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 07:45:09', '0000-00-00 00:00:00'),
(5, 'Ayurveda', 'Sanjeev', 'Gurugram', '8050', 442166644646, 'sanjeev@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 07:47:07', '0000-00-00 00:00:00'),
(6, 'General Physician', 'Amrita', 'New Delhi India', '2500', 45497964, 'amrita@test.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 07:52:50', '0000-00-00 00:00:00'),
(7, 'Demo test', 'abc ', 'New Delhi India', '200', 852888888, 'test@demo.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 08:08:58', '2019-06-23 18:17:25'),
(8, 'Ayurveda', 'Test Doctor', 'Xyz Abc New Delhi', '600', 1234567890, 'test@test.com', '202cb962ac59075b964b07152d234b70', '2019-06-23 17:57:43', '2019-06-23 18:06:06');

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

DROP TABLE IF EXISTS `doctorslog`;
CREATE TABLE IF NOT EXISTS `doctorslog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 2, 'sarita@gmail.com', 0x30000000000000000000000000000000, '2017-01-06 05:53:31', '', 1),
(2, 0, 'admin', 0x3a3a3100000000000000000000000000, '2017-01-06 06:36:07', '', 0),
(3, 2, 'sarita@gmail.com', 0x3a3a3100000000000000000000000000, '2017-01-06 06:36:37', '06/01/2017 07:36:45', 1),
(4, 2, 'sarita@gmail.com', 0x3a3a3100000000000000000000000000, '2017-01-06 06:41:33', '12:11:46', 1),
(5, 2, 'sarita@gmail.com', 0x3a3a3100000000000000000000000000, '2017-01-06 06:55:16', '06-01-2017 12:27:47 PM', 1),
(6, 0, 'admin', 0x3a3a3100000000000000000000000000, '2017-01-06 07:07:12', '', 0),
(7, 0, 'info@w3gang.com', 0x3a3a3100000000000000000000000000, '2017-01-07 08:04:42', '', 0),
(8, 0, 'info@w3gang.com', 0x3a3a3100000000000000000000000000, '2017-01-07 08:04:55', '', 0),
(9, 2, 'sarita@gmail.com', 0x3a3a3100000000000000000000000000, '2017-01-07 08:05:54', '07-01-2017 01:36:28 PM', 1),
(10, 7, 'test@demo.com', 0x3a3a3100000000000000000000000000, '2019-06-23 18:15:31', '23-06-2019 11:47:36 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

DROP TABLE IF EXISTS `doctorspecilization`;
CREATE TABLE IF NOT EXISTS `doctorspecilization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(1, 'Gynecologist/Obstetrician', '2016-12-28 06:37:25', '0000-00-00 00:00:00'),
(2, 'General Physician', '2016-12-28 06:38:12', '0000-00-00 00:00:00'),
(3, 'Dermatologist', '2016-12-28 06:38:48', '0000-00-00 00:00:00'),
(4, 'Homeopath', '2016-12-28 06:39:26', '0000-00-00 00:00:00'),
(5, 'Ayurveda', '2016-12-28 06:39:51', '0000-00-00 00:00:00'),
(6, 'Dentist', '2016-12-28 06:40:08', '0000-00-00 00:00:00'),
(7, 'Ear-Nose-Throat (Ent) Specialist', '2016-12-28 06:41:18', '0000-00-00 00:00:00'),
(9, 'Demo test', '2016-12-28 07:37:39', '0000-00-00 00:00:00'),
(10, 'Bones Specialist demo', '2017-01-07 08:07:53', '0000-00-00 00:00:00'),
(11, 'Test', '2019-06-23 17:51:06', '2019-06-23 17:55:06');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

DROP TABLE IF EXISTS `tblcontactus`;
CREATE TABLE IF NOT EXISTS `tblcontactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext,
  `PostingDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `AdminRemark` mediumtext,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `IsRead` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(1, 'test user', 'test@gmail.com', 2523523522523523, ' This is sample text for the test.', '2019-06-29 19:03:08', 'Test Admin Remark', '2019-06-30 12:55:23', 1),
(2, 'Anuj kumar', 'phpgurukulofficial@gmail.com', 1111111111111111, ' This is sample text for testing.  This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing. This is sample text for testing.', '2019-06-30 13:06:50', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

DROP TABLE IF EXISTS `userlog`;
CREATE TABLE IF NOT EXISTS `userlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(6, 1, '', 0x3a3a3100000000000000000000000000, '2017-01-06 07:02:28', '', 1),
(7, 1, 'info@w3gang.com', 0x3a3a3100000000000000000000000000, '2017-01-06 07:04:28', '', 1),
(8, 0, 'admin', 0x3a3a3100000000000000000000000000, '2017-01-06 07:07:41', '06-01-2017 12:38:09 PM', 0),
(9, 1, 'info@w3gang.com', 0x3a3a3100000000000000000000000000, '2017-01-06 07:08:01', '', 1),
(10, 1, 'info@w3gang.com', 0x3a3a3100000000000000000000000000, '2017-01-06 07:10:09', '06-01-2017 12:41:43 PM', 1),
(11, 2, 'test@gmail.com', 0x3a3a3100000000000000000000000000, '2017-01-07 07:57:18', '07-01-2017 01:27:34 PM', 1),
(12, 0, 'asdad', 0x3a3a3100000000000000000000000000, '2017-01-07 07:57:44', '', 0),
(13, 0, 'xyz@test.com', 0x3a3a3100000000000000000000000000, '2017-01-07 07:59:43', '', 0),
(14, 5, 'amit12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-01-07 08:00:44', '07-01-2017 01:34:19 PM', 1),
(15, 6, 'tetuser@gmail.com', 0x3a3a3100000000000000000000000000, '2019-06-23 18:30:16', '24-06-2019 12:10:17 AM', 1),
(16, 8, 'sumanthreddy329@gmail.com', 0x3a3a3100000000000000000000000000, '2019-10-14 14:14:28', '14-10-2019 07:44:50 PM', 1),
(17, 9, 'ruthvik@gmail.com', 0x3a3a3100000000000000000000000000, '2019-10-14 18:14:46', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(1, 'Anuj kumar', 'Test address', 'Aligarh', 'Males', 'info@w3gang.com', '5c428d8875d2948607f3e3fe134d71b4', '2016-12-26 07:03:09', '2019-06-30 11:59:05'),
(2, 'Sarita pandey', 'New Delhi India', 'Delhi', 'female', 'test@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2016-12-30 05:34:39', '0000-00-00 00:00:00'),
(3, 'Amit', 'New Delhi', 'New delhi', 'male', 'amit@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 06:36:53', '0000-00-00 00:00:00'),
(4, 'Rahul Singh', 'New Delhi', 'New delhi', 'male', 'rahul@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 07:41:14', '0000-00-00 00:00:00'),
(5, 'Amit kumar', 'New Delhi India', 'Delhi', 'male', 'amit12@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-01-07 08:00:26', '2019-10-13 18:30:00'),
(6, 'Test user', 'New Delhi', 'Delhi', 'male', 'tetuser@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2019-06-23 18:24:53', '2019-06-23 18:36:09'),
(7, 'cdsf', 'fsdfsd', 'fdsf', 'male', 'fdsfsd2312@dsfsd.com', 'c20ad4d76fe97759aa27a0c99bff6710', '2019-06-23 18:29:36', '2019-10-13 18:30:00'),
(8, 'Sumanth Reddy ', 'Vit University, Vit University', 'Vellore', 'male', 'sumanthreddy329@gmail.com', '25d55ad283aa400af464c76d713c07ad', '2019-10-14 14:14:10', '2019-10-13 18:30:00'),
(9, 'Ruthvik', 'Vit University, Vit University', 'Vellore', 'male', 'ruthvik@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2019-10-14 18:14:26', '2019-10-13 18:30:00');
--
-- Database: `hospital`
--
CREATE DATABASE IF NOT EXISTS `hospital` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hospital`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('admin@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
CREATE TABLE IF NOT EXISTS `appointments` (
  `appointment_no` int(30) NOT NULL AUTO_INCREMENT,
  `patient_id` int(30) NOT NULL,
  `speciality` varchar(30) NOT NULL,
  `medical_condition` text,
  `doctors_suggestion` varchar(30) DEFAULT NULL,
  `payment_amount` int(199) DEFAULT NULL,
  `case_closed` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`appointment_no`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_no`, `patient_id`, `speciality`, `medical_condition`, `doctors_suggestion`, `payment_amount`, `case_closed`) VALUES
(59, 85, 'Audiologist', 'check', NULL, NULL, 'no'),
(60, 86, 'Audiologist', 'Check', NULL, NULL, 'no'),
(61, 87, 'Audiologist', 'dgg', NULL, NULL, 'no'),
(62, 88, 'Dentist', 'dfhgjh', NULL, NULL, 'no');

-- --------------------------------------------------------

--
-- Table structure for table `clerks`
--

DROP TABLE IF EXISTS `clerks`;
CREATE TABLE IF NOT EXISTS `clerks` (
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='stores information about clerk';

--
-- Dumping data for table `clerks`
--

INSERT INTO `clerks` (`email`, `password`, `fullname`) VALUES
('staff@gmail.com', '123456', 'Staff1');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE IF NOT EXISTS `doctors` (
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `speciality` varchar(30) NOT NULL,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`email`, `password`, `fullname`, `speciality`) VALUES
('doctor1@gmail.com', '123456', 'Doctor1', 'Audiologist'),
('doctor2@gmail.com', '123456', 'Doctor2', 'Dentist');

-- --------------------------------------------------------

--
-- Table structure for table `patient_info`
--

DROP TABLE IF EXISTS `patient_info`;
CREATE TABLE IF NOT EXISTS `patient_info` (
  `patient_Id` int(20) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(20) NOT NULL,
  `DOB` int(10) NOT NULL,
  `weight` int(8) NOT NULL,
  `phone_no` varchar(30) NOT NULL,
  `address` varchar(260) NOT NULL,
  PRIMARY KEY (`patient_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COMMENT='patient';

--
-- Dumping data for table `patient_info`
--

INSERT INTO `patient_info` (`patient_Id`, `full_name`, `DOB`, `weight`, `phone_no`, `address`) VALUES
(85, 'Sumanth Reddy', 19, 56, '9787773988', 'Vit University\r\nVit University'),
(86, 'Ruthvik', 20, 60, '9787773988', 'Vit University\r\nVit University'),
(87, 'Ruthvik', 20, 60, '9787773988', 'Vit University\r\nVit University'),
(88, 'Sumanth Reddy', 20, 56, '9787773988', 'Vit University\r\nVit University');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  UNIQUE KEY `username` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`email`, `password`, `fullname`) VALUES
('ruthvik@gmail.com', '123456', 'Ruthvik'),
('sumanthreddy329@gmail.com', '123456', 'Sumanth Reddy');
--
-- Database: `notes`
--
CREATE DATABASE IF NOT EXISTS `notes` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `notes`;

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(225) NOT NULL,
  `file_description` text NOT NULL,
  `file_type` varchar(225) NOT NULL,
  `file_uploader` varchar(225) NOT NULL,
  `file_uploaded_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_uploaded_to` varchar(225) NOT NULL,
  `file` varchar(225) NOT NULL,
  `status` varchar(225) NOT NULL DEFAULT 'not approved yet',
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`file_id`, `file_name`, `file_description`, `file_type`, `file_uploader`, `file_uploaded_on`, `file_uploaded_to`, `file`, `status`) VALUES
(57, 'demo previer', 'demo', 'pdf', 'user', '2017-07-19 05:08:23', 'Computer Science', '578090.pdf', 'approved'),
(56, 'teacher3 demo', 'demo', 'txt', 'teacher2', '2017-07-19 05:08:16', 'Mechanical', '565834.txt', 'approved'),
(55, 'teacher title', 'demo desc', 'zip', 'teacher', '2017-07-22 06:02:02', 'Mechanical', '898387.zip', 'approved'),
(58, 'phpp demo', 'ppph demo', 'pdf', 'anirban', '2017-07-20 14:52:41', 'Computer Science', '69321.pdf', 'not approved yet'),
(54, 'user title', 'user desc', 'zip', 'student', '2017-07-19 05:08:28', 'Computer Science', '848114.zip', 'approved'),
(53, 'demo title ..', 'demo desc...', 'zip', 'user2', '2017-07-19 04:54:36', 'Electrical', '305047.zip', 'not approved yet'),
(52, 'demo title', 'demo desc......', 'pdf', 'user1', '2017-07-22 06:02:22', 'Electrical', '845248.pdf', 'approved'),
(51, 'demo 3', 'demo 3 desc....', 'pdf', 'user3', '2017-07-22 06:02:15', 'Computer Science', '437056.pdf', 'approved'),
(50, 'demo2', 'demo desc 2...', 'ppt', 'user3', '2017-07-22 06:02:36', 'Computer Science', '800920.ppt', 'approved'),
(49, 'demo title', 'demo description', 'docx', 'user3', '2017-07-19 05:08:13', 'Computer Science', '502238.docx', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `about` varchar(300) NOT NULL DEFAULT 'N/A',
  `role` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `token` varchar(225) NOT NULL,
  `gender` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `course` varchar(225) NOT NULL,
  `image` varchar(225) NOT NULL DEFAULT 'profile.jpg',
  `joindate` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `about`, `role`, `email`, `token`, `gender`, `password`, `course`, `image`, `joindate`) VALUES
(24, 'user', 'user1', 'N/A', 'teacher', 'user@ndndn.cbbc', '', 'Male', '$2y$10$Z1H.ruYjbMSp07EhejzS0O1Fr7PgFdjqbWmtu7/j68TXr55gZ2Msu', 'Computer Science', '107095.jpg', 'July 19, 2017'),
(23, 'teacher2', 'teacher2', 'N/A', 'teacher', 'teacher2hdh@n.fncn', '', 'Male', '$2y$10$rCjs9AHzUSVmITcRJJosgeUxJA5gJ7dZfY16ij/1xf9bzxmFAZzMq', 'Mechanical', '895979.jpg', 'July 19, 2017'),
(22, 'teacher', 'teacher', 'N/A', 'teacher', 'teacher@bfbf.nncn', '', 'Male', '$2y$10$jAk4uQiBQ6b03EVZ0/9i1ucWdNFcVV1dXYj4X2f8uZ4Xd81hBkauG', 'Mechanical', '839669.jpg', 'July 19, 2017'),
(12, 'root', 'admin root', 'N/A', 'admin', 'root@gmail.com', '', 'N/A', '$2y$10$UExd.f8vQXogrZELXF8KGulQJKUn32p8x4B5SVQ7V/D6.mrSAkAjW', 'Computer Science', 'profile.jpg', '2000-01-01'),
(21, 'student', 'student4', 'N/A', 'teacher', 'user4@gmai.com', '', 'Female', '$2y$10$8NTdzG/HXZq5d23o9IqteOY3vWZg75hC99tkuU60/ivcqiQ1sho6.', 'Computer Science', 'profile.jpg', 'July 19, 2017'),
(18, 'user1', 'User 1', 'N/A', 'teacher', 'user1@gmail.com', '', 'Male', '$2y$10$LS76ATZ/jRN/M/pDAyfJmOkNI1MpF08T8NzjNcK.MZKpbjkeMKdMC', 'Electrical', '180812.jpg', 'July 19, 2017'),
(19, 'user2', 'user2', 'i am user', 'student', 'user2@gmail.com', '', 'Female', '$2y$10$OCazXxzd6FM.V2afvmapqOGxVj8Gac3zN.2tlmuO1v1Y3103dqhti', 'Electrical', 'profile.jpg', 'July 19, 2017'),
(20, 'user3', 'user3', 'N/A', 'teacher', 'user3@gmail.com', '', 'Male', '$2y$10$DEKxq9z1r8sWPSzj2XL7LOlT.cUWZv1EbTGZlrXO2VkiBbIuRfoBu', 'Computer Science', 'profile.jpg', 'July 19, 2017'),
(26, 'user6', 'user6', 'N/A', 'teacher', 'user6@gmail.com', '', 'Male', '$2y$10$8OKm1GXZtf4vWTafLHgmjeFls3SvCTWiyXJVhnPr4XOYLeXGOPybW', 'Computer Science', '382911.jpg', 'July 22, 2017'),
(25, 'anirban', 'Anirban', 'N/A', 'teacher', 'anirban.root@gmail.com', 'fbab3eec077a38d565e9c93442178b7d', 'Male', '$2y$10$h4i29DiU8zeLT7EOMLka3uTTCtAxtU.DAExBhywJF3SIRwpHq4wuG', 'Computer Science', '441172.jpg', 'July 20, 2017'),
(27, 'user9', 'hfg gghh', 'N/A', 'teacher', 'ffhhgh@jjdj.vjjv', '', 'Male', '$2y$10$Z1hwjfIGjC8/Zv0NFy/BDO0W.A6K4ZAWLPrW8.himo7YAi0sC7Kjy', 'Computer Science', 'profile.jpg', 'July 22, 2017'),
(28, 'sumanthreddy329', 'Sumanth Reddy', 'N/A', 'student', 'sumanthreddy329@gmail.com', '', 'Male', '$2y$10$AdShHyJrjDgOFruumAyM4.0RgpazXOtgcuQvdWIa0SV9wEkjL.qeq', 'Computer Science', 'profile.jpg', 'October 14, 2019');
--
-- Database: `project1`
--
CREATE DATABASE IF NOT EXISTS `project1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `project1`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `role` varchar(10) DEFAULT 'admin',
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`, `role`) VALUES
('head@gmail.com', 'head', 'head'),
('teacher1@gmail.com', 'teacher1', 'admin'),
('teacher2@gmail.com', 'teacher2', 'admin'),
('teacher3@gmail.com', 'teacher3', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE IF NOT EXISTS `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('55892169bf6a7', '55892169d2efc'),
('5589216a3646e', '5589216a48722'),
('558973f4389ac', '558973f462e61'),
('558973f4c46f2', '558973f4d4abe'),
('558973f51600d', '558973f526fc5'),
('558973f55d269', '558973f57af07'),
('558973f5abb1a', '558973f5e764a'),
('5589751a63091', '5589751a81bf4'),
('5589751ad32b8', '5589751adbdbd'),
('5589751b304ef', '5589751b3b04d'),
('5589751b749c9', '5589751b9a98c'),
('5bd1a29b0514c', '5bd1a29b1c417'),
('5bd1a29b7d4b8', '5bd1a29b8ae6e');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('sumanthreddy329@gmail.com', '5bd1a1a3c5e5b', 0, 2, 0, 2, '2019-10-14 17:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('55892169bf6a7', 'usermod', '55892169d2efc'),
('55892169bf6a7', 'useradd', '55892169d2f05'),
('55892169bf6a7', 'useralter', '55892169d2f09'),
('55892169bf6a7', 'groupmod', '55892169d2f0c'),
('5589216a3646e', '751', '5589216a48713'),
('5589216a3646e', '752', '5589216a4871a'),
('5589216a3646e', '754', '5589216a4871f'),
('5589216a3646e', '755', '5589216a48722'),
('558973f4389ac', 'containing root file-system required during bootup', '558973f462e44'),
('558973f4389ac', ' Contains only scripts to be executed during bootup', '558973f462e56'),
('558973f4389ac', ' Contains root-file system and drivers required to be preloaded during bootup', '558973f462e61'),
('558973f4389ac', 'None of the above', '558973f462e6b'),
('558973f4c46f2', 'Kernel', '558973f4d4abe'),
('558973f4c46f2', 'Shell', '558973f4d4acf'),
('558973f4c46f2', 'Commands', '558973f4d4ad9'),
('558973f4c46f2', 'Script', '558973f4d4ae3'),
('558973f51600d', 'Boot Loading', '558973f526f9d'),
('558973f51600d', ' Boot Record', '558973f526fb9'),
('558973f51600d', ' Boot Strapping', '558973f526fc5'),
('558973f51600d', ' Booting', '558973f526fce'),
('558973f55d269', ' Quick boot', '558973f57aef1'),
('558973f55d269', 'Cold boot', '558973f57af07'),
('558973f55d269', ' Hot boot', '558973f57af17'),
('558973f55d269', ' Fast boot', '558973f57af27'),
('558973f5abb1a', 'bash', '558973f5e7623'),
('558973f5abb1a', ' Csh', '558973f5e7636'),
('558973f5abb1a', ' ksh', '558973f5e7640'),
('558973f5abb1a', ' sh', '558973f5e764a'),
('5589751a63091', 'q', '5589751a81bd6'),
('5589751a63091', 'wq', '5589751a81be8'),
('5589751a63091', ' both (a) and (b)', '5589751a81bf4'),
('5589751a63091', ' none of the mentioned', '5589751a81bfd'),
('5589751ad32b8', ' moves screen down one page', '5589751adbdbd'),
('5589751ad32b8', 'moves screen up one page', '5589751adbdce'),
('5589751ad32b8', 'moves screen up one line', '5589751adbdd8'),
('5589751ad32b8', ' moves screen down one line', '5589751adbde2'),
('5589751b304ef', ' yy', '5589751b3b04d'),
('5589751b304ef', 'yw', '5589751b3b05e'),
('5589751b304ef', 'yc', '5589751b3b069'),
('5589751b304ef', ' none of the mentioned', '5589751b3b073'),
('5589751b749c9', 'X', '5589751b9a98c'),
('5589751b749c9', 'x', '5589751b9a9a5'),
('5589751b749c9', 'D', '5589751b9a9b7'),
('5589751b749c9', 'd', '5589751b9a9c9'),
('5589751bd02ec', 'autoindentation is not possible in vi editor', '5589751bdadaa'),
('5bd1a29b0514c', 'left-root-right', '5bd1a29b1c417'),
('5bd1a29b0514c', 'root-left-right', '5bd1a29b1c42c'),
('5bd1a29b0514c', 'right-left-root', '5bd1a29b1c42d'),
('5bd1a29b0514c', 'none of these', '5bd1a29b1c42e'),
('5bd1a29b7d4b8', 'left-root-right', '5bd1a29b8ae62'),
('5bd1a29b7d4b8', 'root-left-right', '5bd1a29b8ae6e'),
('5bd1a29b7d4b8', 'right-left-root', '5bd1a29b8ae70'),
('5bd1a29b7d4b8', 'none of these', '5bd1a29b8ae71');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('558920ff906b8', '55892169bf6a7', 'what is command for changing user information??', 4, 1),
('558920ff906b8', '5589216a3646e', 'what is permission for view only for other??', 4, 2),
('55897338a6659', '558973f4389ac', 'On Linux, initrd is a file', 4, 1),
('55897338a6659', '558973f4c46f2', 'Which is loaded into memory when system is booted?', 4, 2),
('55897338a6659', '558973f51600d', ' The process of starting up a computer is known as', 4, 3),
('55897338a6659', '558973f55d269', ' Bootstrapping is also known as', 4, 4),
('55897338a6659', '558973f5abb1a', 'The shell used for Single user mode shell is:', 4, 5),
('5589741f9ed52', '5589751a63091', ' Which command is used to close the vi editor?', 4, 1),
('5589741f9ed52', '5589751ad32b8', ' In vi editor, the key combination CTRL+f', 4, 2),
('5589741f9ed52', '5589751b304ef', ' Which vi editor command copies the current line of the file?', 4, 3),
('5589741f9ed52', '5589751b749c9', ' Which command is used to delete the character before the cursor location in vi editor?', 4, 4),
('5589741f9ed52', '5589751bd02ec', ' Which one of the following statement is true?', 4, 5),
('5bd1a1a3c5e5b', '5bd1a29b0514c', 'What is inorder?', 4, 1),
('5bd1a1a3c5e5b', '5bd1a29b7d4b8', 'what is pre order?', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
CREATE TABLE IF NOT EXISTS `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`, `email`) VALUES
('558920ff906b8', 'Linux : File Managment', 2, 1, 2, 5, '', 'linux', '2018-10-20 14:47:56', 'teacher2@gmail.com'),
('55897338a6659', 'Linux:startup', 2, 1, 5, 10, '', 'linux', '2018-10-20 14:47:56', 'teacher2@gmail.com'),
('5589741f9ed52', 'Linux :vi Editor', 2, 1, 5, 10, '', 'linux', '2018-10-20 14:47:56', 'teacher2@gmail.com'),
('5bd1a1a3c5e5b', 'Data Structure', 1, 0, 2, 1, 'ds exam', 'ds', '2018-10-25 10:57:39', 'teacher2@gmail.com'),
('5da4b60708269', 'E-governance', 1, 0, 10, 10, 'E-Governance Quiz-1', '#Quiz1', '2019-10-14 17:53:11', 'teacher1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

DROP TABLE IF EXISTS `rank`;
CREATE TABLE IF NOT EXISTS `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('sumanthreddy329@gmail.com', 0, '2019-10-14 17:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Sumanth', 'M', 'VIT UNIVERSITY', 'sumanthreddy329@gmail.com', 9787773988, '25d55ad283aa400af464c76d713c07ad');
--
-- Database: `s`
--
CREATE DATABASE IF NOT EXISTS `s` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `s`;
--
-- Database: `sample`
--
CREATE DATABASE IF NOT EXISTS `sample` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sample`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(11) NOT NULL,
  `discount_code` char(1) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `addressline1` varchar(30) DEFAULT NULL,
  `addressline2` varchar(30) DEFAULT NULL,
  `city` varchar(25) DEFAULT NULL,
  `state` char(2) DEFAULT NULL,
  `phone` char(12) DEFAULT NULL,
  `fax` char(12) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `credit_limit` int(11) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `FOREIGNKEY_discount_code` (`discount_code`),
  KEY `FOREIGNKEY_zip` (`zip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `discount_code`, `zip`, `name`, `addressline1`, `addressline2`, `city`, `state`, `phone`, `fax`, `email`, `credit_limit`) VALUES
(1, 'N', '33015', 'JumboCom', '111 E. Las Olas Blvd', 'Suite 51', 'Fort Lauderdale', 'FL', '305-777-4632', '305-777-4635', 'jumbocom@gmail.com', 100000),
(2, 'M', '33055', 'Livermore Enterprises', '9754 Main Street', 'P.O. Box 567', 'Miami', 'FL', '305-456-8888', '305-456-8889', 'www.tsoftt.com', 50000),
(3, 'L', '12347', 'Nano Apple', '8585 Murray Drive', 'P.O. Box 456', 'Alanta', 'GA', '555-275-9900', '555-275-9911', 'www.nanoapple.net', 90000),
(25, 'M', '75200', 'Oak Computers', '8989 Qume Drive', 'Suite 9897', 'Houston', 'TX', '214-999-1234', '214-999-5432', 'www.oakc.com', 25000),
(36, 'H', '94401', 'HostProCom', '65653 El Camino', 'Suite 2323', 'San Mateo', 'CA', '650-456-8876', '650-456-1120', 'www.hostprocom.net', 65000),
(106, 'L', '95035', 'CentralComp', '829 Flex Drive', 'Suite 853', 'San Jose', 'CA', '408-987-1256', '408-987-1277', 'www.centralcomp.com', 26500),
(149, 'L', '95117', 'Golden Valley Computers', '4381 Kelly Ave', 'Suite 77', 'Santa Clara', 'CA', '408-432-6868', '408-432-6899', 'www.gvc.net', 70000),
(409, 'L', '10095', 'New Media productions', '4400 22nd Street', 'Suite 562', 'New York', 'NY', '212-222-5656', '212-222-5600', 'www.nymedia.com', 10000),
(410, 'M', '10096', 'Yankee Computer Repair', '9653 33rd Ave', 'Floor 4', 'New York', 'NY', '212-535-7000', '212-535-7100', 'www.nycomp@repair.com', 25000),
(722, 'N', '48124', 'Big Car Parts', '52963 Outer Dr', 'Suite 35', 'Detroit', 'MI', '313-788-7682', '313-788-7600', 'www.sparts.com', 50000),
(753, 'H', '48128', 'Ford Motor Co', '2267 Michigan Ave', 'Building 21', 'Dearborn', 'MI', '313-787-2100', '313-787-3100', 'www.parts@ford.com', 5000000),
(777, 'L', '48128', 'West Valley Inc.', '88 North Drive', 'Building C', 'Dearborn', 'MI', '313-563-9900', '313-563-9911', 'www.westv.com', 100000),
(863, 'N', '94401', 'Top Network Systems', '456 4th Street', 'Suite 45', 'Redwood city', 'CA', '650-345-5656', '650-345-4433', 'www.hpsys.net', 25000);

-- --------------------------------------------------------

--
-- Table structure for table `discount_code`
--

DROP TABLE IF EXISTS `discount_code`;
CREATE TABLE IF NOT EXISTS `discount_code` (
  `discount_code` char(1) NOT NULL,
  `rate` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`discount_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discount_code`
--

INSERT INTO `discount_code` (`discount_code`, `rate`) VALUES
('H', '16.00'),
('L', '7.00'),
('M', '11.00'),
('N', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `manufacturer`
--

DROP TABLE IF EXISTS `manufacturer`;
CREATE TABLE IF NOT EXISTS `manufacturer` (
  `manufacturer_id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `addressline1` varchar(30) DEFAULT NULL,
  `addressline2` varchar(30) DEFAULT NULL,
  `city` varchar(25) DEFAULT NULL,
  `state` char(2) DEFAULT NULL,
  `zip` char(10) DEFAULT NULL,
  `phone` varchar(12) DEFAULT NULL,
  `fax` varchar(12) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `rep` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`manufacturer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manufacturer`
--

INSERT INTO `manufacturer` (`manufacturer_id`, `name`, `addressline1`, `addressline2`, `city`, `state`, `zip`, `phone`, `fax`, `email`, `rep`) VALUES
(19941212, 'Sun MicroSystems', '4000 Network Circle', 'Building 19', 'Santa Clara', 'CA', '95051', '206-972-4452', '206-972-4699', 'javaee5@sun.com', 'bill snider'),
(19948494, 'Computer Cables & More', '5632 Michigam Ave', ' ', 'Dearborn', 'MI', '48127', '313-555-6654', '313-555-6600', 'www.cbl.more.net', 'Sam Frank'),
(19955564, 'Sun MicroSystems', '4000 Network Circle', 'Building 15', 'Santa Clara', 'CA', '95051', '206-972-4457', '206-972-4499', 'insider@cnet.com', 'Cest commentquonfreine'),
(19955565, 'Sun MicroSystems', '4000 Network Circle', 'Building 16', 'Santa Clara', 'CA', '95051', '206-972-4458', '206-972-4499', 'outsidert@cnet.com', 'Wanabe There'),
(19955656, 'SoftClip', '95 Eastway Drive', 'Building 1', 'Boston', 'MA', '02100', '617-998-5656', '617-998-9988', 'www.soft@clip.com', 'Rhonda Nelson'),
(19960022, 'Dobs Computer products', '6593 Garcia Way', 'Floor 2', 'Albuqerque', 'NM', '87119', '505-999-2121', '505-999-2100', 'www.dobs@aol.com', 'Tom Goglia'),
(19963322, 'Bank Of America', '236 Market St.', 'Suite 666', 'San Francisco', 'CA', '94567', '415-875-4746', '415-875-8000', 'www.boa.com', 'John White'),
(19963323, 'Google', '7655 2st Street', 'Suite 200', 'Mountain View', 'CA', '94043', '408-456-6677', '408-456-9972', 'www.google@gmail.com', 'John Green'),
(19963324, 'Google', '7654 1st Street', 'Suite 100', 'Mountain View', 'CA', '94043', '408-456-6688', '408-456-9900', 'www.google@gmail.com', 'Fred Stanford'),
(19963325, 'Google', '7654 1st Street', 'Suite 150', 'Mountain View', 'CA', '94043', '408-456-6688', '408-456-9900', 'www.google@gmail.com', '7 of 9'),
(19965794, 'Getaway', '975 El Camino Real', 'Suite 55', 'Santa Clara', 'CA', '95051', '408-261-9826', '408-261-9895', 'www.computer@gate.com', 'Hans Frisby'),
(19971233, 'BMC', '5960 Inglewood drive', 'Building R5', 'Pleasanton', 'CA', '94588', '408-321-8800', '408-321-8811', 'www.paul@bmc.com', 'Paul Cruz'),
(19974892, 'Acer', '20959 Bascom Ave', 'Building 3', 'San Jose', 'CA', '95128', '408-293-9123', '408-293-0070', 'www.acer@tech.com', 'Matt Williams'),
(19977346, 'Hitachi', '284 Smith Road', 'Suite 7', 'San Mateo', 'CA', '94403', '650-765-7878', '650-329-8494', 'www.smith.com', 'Frank Smith'),
(19977347, 'World Savings', '56 Broadway', 'Floor 12', 'Oakland', 'CA', '98123', '510-683-9725', '510-683-9510', 'www.wsl.com', 'Tom Brown'),
(19977348, 'Wells Fargo', '235 Market St.', 'Suite 666', 'San Francisco', 'CA', '94567', '415-876-4747', '415-876-9000', 'www.wfb.com', 'John Adams'),
(19977775, 'Sams Publishing', '944 West 103rd Street', 'Suite 25', 'Reading', 'MA', '01867', '617-212-1643', '617-212-1600', 'www.books@sams.com', 'Paul Schaffer'),
(19978451, '3Com', '399 San Pablo Ave', 'Building 600', 'El Cerrito', 'CA', '94530', '510-528-7777', '510-528-7766', 'www.3com@aol.com', 'Lefty Groff'),
(19980198, 'Rico Enterprises', '76342 26th Ave', 'Suite 450', 'New York', 'NY', '10044', '212-766-7531', '212-766-7500', 'www.rico@aol.com', 'Fred Lewis'),
(19982461, 'CBX Cables', '9988 Main Street', 'Suite 100', 'Indianapolis', 'IN', '46290', '800-987-3434', '800-987-1111', 'www.cbx@cbl.com', 'Henry Adams'),
(19984681, 'Sun MicroSystems', '4000 Network Circle', 'Building 17', 'Santa Clara', 'CA', '95051', '206-972-4459', '206-972-4399', 'app.send@sun.com', 'Cesar Palace'),
(19984682, 'Sun MicroSystems', '4000 Network Circle', 'Building 18', 'Santa Clara', 'CA', '95051', '206-972-4451', '206-972-4599', 'j2ee@sun.com', 'Waren Julius'),
(19984899, 'Sony', '5109 Union Street', 'Building 8A', 'San Francisco', 'CA', '94123', '415-885-9090', '415-885-9099', 'www.sales@sony.com', 'Laura Chinn'),
(19985590, 'Sun MicroSystems', '4000 Network Circle', 'Building 14', 'Santa Clara', 'CA', '95051', '206-972-4456', '206-972-4499', 'ann.best@sun.com', 'Sun Soft'),
(19985678, 'Google', '7654 1st Street', 'Suite 100', 'Mountain View', 'CA', '94043', '650-456-6688', '408-456-9900', 'www.google@gmail.com', 'John Snow'),
(19986196, 'Matrox', '250 Marin Blvd', 'Suite C', 'Novato', 'CA', '94949', '415-883-9832', '415-883-9811', 'www.mat@comp.net', 'Brad Bonds'),
(19986542, 'Zetsoft', '795 Stone Road', 'Suite 4', 'Tombstone', 'AZ', '85638', '602-545-9823', '602-545-9800', 'www.zetasoft.com', 'Hugh Klein'),
(19986982, 'Sun MicroSystems', '4000 Network Circle', 'Building 14', 'Santa Clara', 'CA', '95051', '408-972-4456', '408-972-4499', 'www.msft@cnet.com', 'Brian Washington'),
(19987296, 'Sun MicroSystems', '4000 Network Circle', 'Building 20', 'Santa Clara', 'CA', '95051', '206-972-4453', '206-972-4799', 'gerard@cnet.com', 'gerard dekerantarec'),
(19987297, 'Livermore Enterprises', '9754 Main Street', 'P.O. Box 567', 'Miami', 'FL', '33055', '206-972-4453', '206-972-4799', 'jumbocom@gmail.com', 'Livermore Enterprises'),
(19987298, 'JumboCom', '111 E. Las Olas Blvd', 'Suite 51', 'Fort Lauderdale', 'FL', '33015', '206-972-4453', '206-972-4799', 'www.tsoftt.com', 'JumboCom'),
(19987299, 'Oak Computers', '8989 Qume Drive', 'Suite 9897', 'Houston', 'TX', '75200', '206-972-4453', '206-972-4799', 'www.oakc.com', 'Oak Computers'),
(19989719, 'Toshiba', '1000 Van Nuys Blvd', 'Suite 33', 'Van Nuys', 'CA', '91405', '800-997-0065', '800-997-0099', 'www.tsales@toshiba.com', 'Charlotte Wise');

-- --------------------------------------------------------

--
-- Table structure for table `micro_market`
--

DROP TABLE IF EXISTS `micro_market`;
CREATE TABLE IF NOT EXISTS `micro_market` (
  `zip_code` varchar(10) NOT NULL,
  `radius` double DEFAULT NULL,
  `area_length` double DEFAULT NULL,
  `area_width` double DEFAULT NULL,
  PRIMARY KEY (`zip_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `micro_market`
--

INSERT INTO `micro_market` (`zip_code`, `radius`, `area_length`, `area_width`) VALUES
('10095', 1987.854, 975.875, 865.681),
('10096', 1876.766, 955.666, 923.556),
('12347', 475.965, 385.849, 146.937),
('33015', 1876.766, 955.666, 923.556),
('33055', 1876.766, 955.666, 923.556),
('48124', 753.765, 487.664, 456.632),
('48128', 684.675, 475.854, 408.074),
('75200', 1876.766, 955.666, 923.556),
('85638', 758.648, 328.963, 482.164),
('94043', 157.869, 385.821, 147.538),
('94401', 368.386, 285.848, 173.794),
('95035', 683.396, 472.859, 379.757),
('95051', 255.59, 689.856, 478.479),
('95117', 755.778, 547.967, 468.858);

-- --------------------------------------------------------

--
-- Table structure for table `one`
--

DROP TABLE IF EXISTS `one`;
CREATE TABLE IF NOT EXISTS `one` (
  `user` varchar(35) DEFAULT NULL,
  `pass` varchar(35) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` int(11) NOT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `product_code` char(2) NOT NULL,
  `purchase_cost` decimal(12,2) DEFAULT NULL,
  `quantity_on_hand` int(11) DEFAULT NULL,
  `markup` decimal(4,2) DEFAULT NULL,
  `available` varchar(5) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `FOREIGNKEY_manufacturer_id` (`manufacturer_id`),
  KEY `FOREIGNKEY_product_code` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `manufacturer_id`, `product_code`, `purchase_cost`, `quantity_on_hand`, `markup`, `available`, `description`) VALUES
(948933, 19941212, 'MS', '36.95', 50, '75.00', 'TRUE', 'Computer Tool Kit'),
(958888, 19955564, 'HW', '799.99', 0, '1.50', 'FALSE', 'Ultra Spacr 999Mhz Computer'),
(958889, 19955565, 'HW', '595.95', 0, '1.25', 'FALSE', '686 7Ghz Computer'),
(964025, 19963322, 'SW', '209.95', 300, '41.00', 'TRUE', 'Jax WS Application Development Environment'),
(964026, 19963323, 'SW', '259.95', 220, '51.00', 'TRUE', 'Java EE 6 Application Development Environment'),
(964027, 19963324, 'SW', '269.95', 700, '61.00', 'TRUE', 'Java Application Development Environment'),
(964028, 19963325, 'SW', '219.95', 300, '32.00', 'TRUE', 'NetBeans Development Environment'),
(971266, 19948494, 'CB', '25.95', 500, '30.00', 'TRUE', 'Network Cable'),
(975789, 19977775, 'BK', '29.98', 25, '5.00', 'TRUE', 'Learn Solaris 10'),
(978493, 19977346, 'BK', '19.95', 100, '5.00', 'TRUE', 'Client Server Testing'),
(978494, 19977347, 'BK', '18.95', 43, '4.00', 'TRUE', 'Learn Java in 1/2 hour'),
(978495, 19977348, 'BK', '24.99', 0, '1.00', 'FALSE', 'Writing Web Service Applications'),
(980001, 19985678, 'SW', '1095.00', 800000, '8.25', 'TRUE', 'identity Server'),
(980002, 19960022, 'MS', '75.00', 0, '12.00', 'FALSE', 'Corporate Expense Survey'),
(980005, 19986982, 'SW', '11500.99', 500, '55.25', 'TRUE', 'Accounting Application'),
(980025, 19974892, 'HW', '2095.99', 3000, '15.75', 'TRUE', '1Ghz Sun Blade Computer'),
(980030, 19986196, 'FW', '59.95', 250, '40.00', 'TRUE', '10Gb Ram'),
(980031, 19986542, 'SW', '595.95', 75, '14.00', 'TRUE', 'Sun Studio C++'),
(980032, 19978451, 'FW', '39.95', 50, '25.50', 'TRUE', 'Sound Card'),
(980122, 19985590, 'HW', '1400.95', 100, '25.00', 'TRUE', 'Solaris x86 Computer'),
(980500, 19980198, 'BK', '29.95', 1000, '33.00', 'TRUE', 'Learn NetBeans'),
(980601, 19971233, 'HW', '2000.95', 2000, '25.00', 'TRUE', '300Mhz Pentium Computer'),
(984666, 19987296, 'HW', '199.95', 25, '45.00', 'TRUE', 'Flat screen Monitor'),
(985510, 19984899, 'HW', '595.00', 800, '5.75', 'TRUE', '24 inch Digital Monitor'),
(986420, 19955656, 'SW', '49.95', 0, '5.25', 'FALSE', 'Directory Server'),
(986710, 19982461, 'CB', '15.98', 400, '30.00', 'TRUE', 'Printer Cable'),
(986712, 19989719, 'HW', '69.95', 1000, '10.50', 'TRUE', '512X idE DVD-ROM'),
(986733, 19984681, 'HW', '69.98', 400, '55.00', 'TRUE', 'A1 900 watts Speakers'),
(986734, 19984682, 'HW', '49.95', 200, '65.00', 'TRUE', 'Mini Computer Speakers'),
(988765, 19965794, 'HW', '10.95', 25, '9.75', 'TRUE', '104-Key Keyboard');

-- --------------------------------------------------------

--
-- Table structure for table `product_code`
--

DROP TABLE IF EXISTS `product_code`;
CREATE TABLE IF NOT EXISTS `product_code` (
  `prod_code` char(2) NOT NULL,
  `discount_code` char(1) NOT NULL,
  `description` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`prod_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_code`
--

INSERT INTO `product_code` (`prod_code`, `discount_code`, `description`) VALUES
('BK', 'L', 'Books'),
('CB', 'N', 'Cables'),
('FW', 'L', 'Firmware'),
('HW', 'H', 'Hardware'),
('MS', 'N', 'Misc'),
('SW', 'M', 'Software');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

DROP TABLE IF EXISTS `purchase_order`;
CREATE TABLE IF NOT EXISTS `purchase_order` (
  `order_num` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` smallint(6) DEFAULT NULL,
  `shipping_cost` decimal(12,2) DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `shipping_date` date DEFAULT NULL,
  `freight_company` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`order_num`),
  KEY `FOREIGNKEY_customer_id` (`customer_id`),
  KEY `FOREIGNKEY_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_order`
--

INSERT INTO `purchase_order` (`order_num`, `customer_id`, `product_id`, `quantity`, `shipping_cost`, `sales_date`, `shipping_date`, `freight_company`) VALUES
(10398001, 1, 980001, 10, '449.00', '2019-10-14', '2019-10-14', 'Poney Express'),
(10398002, 2, 980005, 8, '359.99', '2019-10-14', '2019-10-14', 'Poney Express'),
(10398003, 2, 980025, 25, '275.00', '2019-10-14', '2019-10-14', 'Poney Express'),
(10398004, 3, 980030, 10, '275.00', '2019-10-14', '2019-10-14', 'Poney Express'),
(10398005, 1, 980032, 100, '459.00', '2019-10-14', '2019-10-14', 'Poney Express'),
(10398006, 36, 986710, 60, '55.00', '2019-10-14', '2019-10-14', 'Slow Snail'),
(10398007, 36, 985510, 120, '65.00', '2019-10-14', '2019-10-14', 'Slow Snail'),
(10398008, 106, 988765, 500, '265.00', '2019-10-14', '2019-10-14', 'Slow Snail'),
(10398009, 149, 986420, 1000, '700.00', '2019-10-14', '2019-10-14', 'Western Fast'),
(10398010, 863, 986712, 100, '25.00', '2019-10-14', '2019-10-14', 'Slow Snail'),
(20198001, 777, 971266, 75, '105.00', '2019-10-14', '2019-10-14', 'We deliver'),
(20598100, 753, 980601, 100, '200.99', '2019-10-14', '2019-10-14', 'We deliver'),
(20598101, 722, 980500, 250, '2500.00', '2019-10-14', '2019-10-14', 'Coastal Freight'),
(30198001, 409, 980001, 50, '2000.99', '2019-10-14', '2019-10-14', 'Southern Delivery Service'),
(30298004, 410, 980031, 100, '700.00', '2019-10-14', '2019-10-14', 'FR Express');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`discount_code`) REFERENCES `discount_code` (`discount_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `customer_ibfk_2` FOREIGN KEY (`zip`) REFERENCES `micro_market` (`zip_code`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`manufacturer_id`) REFERENCES `manufacturer` (`manufacturer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`product_code`) REFERENCES `product_code` (`prod_code`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD CONSTRAINT `purchase_order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `purchase_order_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
--
-- Database: `tms`
--
CREATE DATABASE IF NOT EXISTS `tms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tms`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', 'f925916e2754e5e03f75dd58a5733251', '2017-05-13 11:18:49');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

DROP TABLE IF EXISTS `tblbooking`;
CREATE TABLE IF NOT EXISTS `tblbooking` (
  `BookingId` int(11) NOT NULL AUTO_INCREMENT,
  `PackageId` int(11) NOT NULL,
  `UserEmail` varchar(100) NOT NULL,
  `FromDate` varchar(100) NOT NULL,
  `ToDate` varchar(100) NOT NULL,
  `Comment` mediumtext NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  `CancelledBy` varchar(5) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`BookingId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`BookingId`, `PackageId`, `UserEmail`, `FromDate`, `ToDate`, `Comment`, `RegDate`, `status`, `CancelledBy`, `UpdationDate`) VALUES
(2, 1, 'anuj@gmail.com', '05/18/2017', '05/31/2017', '\"Lorem ipsum dolor sit amet, cpariatur. Excepteur sint ', '2017-05-13 19:01:10', 2, 'u', '2017-05-13 21:30:23'),
(3, 2, 'anuj@gmail.com', '05/16/2017', '05/31/2017', 'casf esd sg gd gdfh df', '2017-05-13 20:20:01', 2, 'a', '2017-05-13 23:04:40'),
(4, 1, 'anuj@gmail.com', '05/16/2017', '05/31/2017', 'dwef  fwe', '2017-05-13 20:32:54', 2, 'a', '2017-05-13 21:36:39'),
(5, 1, 'anuj@gmail.com', '05/16/2017', '05/31/2017', 'dwef  fwe', '2017-05-13 20:33:17', 1, NULL, '2017-05-13 23:11:35'),
(6, 2, 'anuj@gmail.com', '05/14/2017', '05/24/2017', 'test demo', '2017-05-13 21:18:37', 2, 'a', '2017-05-14 07:58:28'),
(7, 4, 'sarita@gmail.com', '05/26/2017', '05/30/2017', 'est laborum.\" velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\" velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2017-05-14 05:09:11', 2, 'a', '2017-05-14 07:47:39'),
(8, 2, 'sarita@gmail.com', '05/27/2017', '05/28/2017', 'ubub5u6', '2017-05-14 05:10:24', 2, 'a', '2017-05-14 05:13:03'),
(9, 1, 'demo@test.com', '05/19/2017', '05/21/2017', 'demo test demo test', '2017-05-14 07:45:11', 1, NULL, '2017-05-14 07:47:45'),
(10, 5, 'abc@g.com', '05/22/2017', '05/24/2017', 'test test t test test ttest test ttest test ttest test ttest test ttest test ttest test ttest test ttest test ttest test ttest test ttest test ttest test t', '2017-05-14 07:56:26', 1, NULL, '2017-05-14 07:58:19'),
(11, 5, 'pranay@gmail.com', '2019-10-15', '2019-10-14', 'jhjbh', '2019-10-10 11:49:38', 0, NULL, NULL),
(12, 5, 'pranay@gmail.com', '2019-10-23', '2019-10-30', 'ooty', '2019-10-10 11:52:09', 1, NULL, '2019-10-10 11:52:24');

-- --------------------------------------------------------

--
-- Table structure for table `tblenquiry`
--

DROP TABLE IF EXISTS `tblenquiry`;
CREATE TABLE IF NOT EXISTS `tblenquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(100) NOT NULL,
  `EmailId` varchar(100) NOT NULL,
  `MobileNumber` char(10) NOT NULL,
  `Subject` varchar(100) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblenquiry`
--

INSERT INTO `tblenquiry` (`id`, `FullName`, `EmailId`, `MobileNumber`, `Subject`, `Description`, `PostingDate`, `Status`) VALUES
(1, 'anuj', 'anuj.lpu1@gmail.com', '2354235235', 'The standard Lorem Ipsum passage, used since the 1500s', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum', '2017-05-13 22:23:53', 1),
(2, 'efgegter', 'terterte@gmail.com', '3454353453', 'The standard Lorem Ipsum passage', 'nventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat volup', '2017-05-13 22:27:00', 1),
(3, 'fwerwetrwet', 'fwsfhrtre@hdhdhqw.com', '8888888888', 'erwt wet', 'nventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat volup', '2017-05-13 22:28:11', 1),
(4, 'Test', 'test@gm.com', '4747474747', 'Test', 'iidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiidiid', '2017-05-14 07:54:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblissues`
--

DROP TABLE IF EXISTS `tblissues`;
CREATE TABLE IF NOT EXISTS `tblissues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `UserEmail` varchar(100) NOT NULL,
  `Issue` varchar(100) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `AdminRemark` mediumtext,
  `AdminremarkDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblissues`
--

INSERT INTO `tblissues` (`id`, `UserEmail`, `Issue`, `Description`, `PostingDate`, `AdminRemark`, `AdminremarkDate`) VALUES
(4, 'anuj@gmail.com', 'Cancellation', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco ', '2017-05-13 22:03:33', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur', '2017-05-13 23:50:40'),
(5, 'sarita@gmail.com', 'Cancellation', 'tbt 3y 34y4 3y3hgg34t', '2017-05-14 05:12:14', 'sg sd gs g sdgfs ', '2017-05-14 07:52:07'),
(6, 'demo@test.com', 'Refund', 'demo test.com demo test.comdemo test.comdemo test.comdemo test.com', '2017-05-14 07:45:37', NULL, '0000-00-00 00:00:00'),
(7, 'abc@g.com', 'Refund', 'test test ttest test ttest test ttest test ttest test ttest test t', '2017-05-14 07:56:46', 'vetet ert erteryre', '2017-05-14 07:58:43');

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

DROP TABLE IF EXISTS `tblpages`;
CREATE TABLE IF NOT EXISTS `tblpages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `type`, `detail`) VALUES
(1, 'terms', '<P align=justify><FONT size=2><STRONG><FONT color=#990000>(1) ACCEPTANCE OF TERMS</FONT><BR><BR></STRONG>Welcome to Yahoo! India. 1Yahoo Web Services India Private Limited Yahoo\", \"we\" or \"us\" as the case may be) provides the Service (defined below) to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time at: <A href=\"http://in.docs.yahoo.com/info/terms/\">http://in.docs.yahoo.com/info/terms/</A>. In addition, when using particular Yahoo services or third party services, you and Yahoo shall be subject to any posted guidelines or rules applicable to such services which may be posted from time to time. All such guidelines or rules, which maybe subject to change, are hereby incorporated by reference into the TOS. In most cases the guides and rules are specific to a particular part of the Service and will assist you in applying the TOS to that part, but to the extent of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Services, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Services. Yahoo also may offer other services from time to time that are governed by different Terms of Services. These TOS do not apply to such other services that are governed by different Terms of Service. </FONT></P>\r\n<P align=justify><FONT size=2>Welcome to Yahoo! India. Yahoo Web Services India Private Limited Yahoo\", \"we\" or \"us\" as the case may be) provides the Service (defined below) to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time at: </FONT><A href=\"http://in.docs.yahoo.com/info/terms/\"><FONT size=2>http://in.docs.yahoo.com/info/terms/</FONT></A><FONT size=2>. In addition, when using particular Yahoo services or third party services, you and Yahoo shall be subject to any posted guidelines or rules applicable to such services which may be posted from time to time. All such guidelines or rules, which maybe subject to change, are hereby incorporated by reference into the TOS. In most cases the guides and rules are specific to a particular part of the Service and will assist you in applying the TOS to that part, but to the extent of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Services, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Services. Yahoo also may offer other services from time to time that are governed by different Terms of Services. These TOS do not apply to such other services that are governed by different Terms of Service. </FONT></P>\r\n<P align=justify><FONT size=2>Welcome to Yahoo! India. Yahoo Web Services India Private Limited Yahoo\", \"we\" or \"us\" as the case may be) provides the Service (defined below) to you, subject to the following Terms of Service (\"TOS\"), which may be updated by us from time to time without notice to you. You can review the most current version of the TOS at any time at: </FONT><A href=\"http://in.docs.yahoo.com/info/terms/\"><FONT size=2>http://in.docs.yahoo.com/info/terms/</FONT></A><FONT size=2>. In addition, when using particular Yahoo services or third party services, you and Yahoo shall be subject to any posted guidelines or rules applicable to such services which may be posted from time to time. All such guidelines or rules, which maybe subject to change, are hereby incorporated by reference into the TOS. In most cases the guides and rules are specific to a particular part of the Service and will assist you in applying the TOS to that part, but to the extent of any inconsistency between the TOS and any guide or rule, the TOS will prevail. We may also offer other services from time to time that are governed by different Terms of Services, in which case the TOS do not apply to such other services if and to the extent expressly excluded by such different Terms of Services. Yahoo also may offer other services from time to time that are governed by different Terms of Services. These TOS do not apply to such other services that are governed by different Terms of Service. </FONT></P>'),
(2, 'Privacy', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat</span>'),
(3, 'aboutus', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Test test</span>'),
(11, 'contact', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Address------Test</span>');

-- --------------------------------------------------------

--
-- Table structure for table `tbltourpackages`
--

DROP TABLE IF EXISTS `tbltourpackages`;
CREATE TABLE IF NOT EXISTS `tbltourpackages` (
  `PackageId` int(11) NOT NULL AUTO_INCREMENT,
  `PackageName` varchar(200) NOT NULL,
  `PackageType` varchar(150) NOT NULL,
  `PackageLocation` varchar(100) NOT NULL,
  `PackagePrice` int(11) NOT NULL,
  `PackageFetures` varchar(255) NOT NULL,
  `PackageDetails` mediumtext NOT NULL,
  `PackageImage` varchar(100) NOT NULL,
  `Creationdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PackageId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltourpackages`
--

INSERT INTO `tbltourpackages` (`PackageId`, `PackageName`, `PackageType`, `PackageLocation`, `PackagePrice`, `PackageFetures`, `PackageDetails`, `PackageImage`, `Creationdate`, `UpdationDate`) VALUES
(1, 'Manali Trip ', 'General', 'Kullu Manali India', 100, 'Air Conditioning ,Balcony / Terrace,Cable / Satellite / Pay TV available,Ceiling Fan,Hairdryer', '\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"', '14287acc-b5cb-46db-b8b4-e3ffe652fc0d.png', '2017-05-13 14:23:44', '2017-05-13 17:51:01'),
(2, 'kashmir', 'holiday', 'Kashmir', 5433, '1 week trip', 'kashmir', 'Pahalgam_Valley.jpg', '2017-05-13 15:24:26', '2019-10-10 11:45:38'),
(4, 'Kerla', 'Familty and Couple', 'Kerlal', 2000, 'kerala', 'kerala', 'images.jpg', '2017-05-13 22:39:37', '2019-10-10 11:46:15'),
(5, 'Coorg : Tour Packages', 'General', 'Coorg', 3000, 'coorg', 'coorg', 'coorg-hill-station1.jpg', '2017-05-13 22:42:10', '2019-10-10 11:46:41'),
(6, 'Varanasi', 'Family', 'varnasi', 5000, 'Frree wifi, pickup and drop etcanasi', 'varnasi', 'Varanasi.jpg', '2017-05-14 08:01:08', '2019-10-10 11:48:01');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
CREATE TABLE IF NOT EXISTS `tblusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(100) NOT NULL,
  `MobileNumber` char(10) NOT NULL,
  `EmailId` varchar(70) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EmailId` (`EmailId`),
  KEY `EmailId_2` (`EmailId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `MobileNumber`, `EmailId`, `Password`, `RegDate`, `UpdationDate`) VALUES
(1, 'Anuj kumar', '1111111111', 'anuj@gmail.com', '5c428d8875d2948607f3e3fe134d71b4', '2017-05-10 10:38:17', '2017-05-13 19:36:08'),
(3, 'Pranay', '9999999999', 'pranay@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2017-05-10 10:50:48', '2019-10-10 11:42:04'),
(7, 'test', '7676767676', 'test@gm.com', 'f925916e2754e5e03f75dd58a5733251', '2017-05-10 10:54:56', '0000-00-00 00:00:00'),
(8, 'Anuj kumar', '9999999999', 'demo@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-05-14 07:17:44', '0000-00-00 00:00:00'),
(9, 'XYZabc', '3333333333', 'xyz@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2017-05-14 07:25:13', '2017-05-14 07:25:42'),
(10, 'Anuj Kumar', '4543534534', 'demo@test.com', 'f925916e2754e5e03f75dd58a5733251', '2017-05-14 07:43:23', '2017-05-14 07:46:57'),
(11, 'XYZ', '8888888888', 'abc@g.com', 'f925916e2754e5e03f75dd58a5733251', '2017-05-14 07:54:32', '2017-05-14 07:55:17');
--
-- Database: `uday`
--
CREATE DATABASE IF NOT EXISTS `uday` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `uday`;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
